"""
Preprocess raw tracking and event data into the normalized schema.

This script demonstrates how to convert raw annotations into the four
primary tables: Games, Players, Plays and Tracking.  It reads
YOLO‑format labels and constructs simple synthetic tracking records.  The
resulting CSV files can be loaded into PostGIS or used directly in the
feature engineering pipeline.
"""
import argparse
import csv
import os
import random
from typing import List


def generate_dummy_data(input_dir: str, output_dir: str) -> None:
    """Generate synthetic tables as placeholders.

    In a real pipeline you would parse your annotations and event logs here.
    """
    os.makedirs(output_dir, exist_ok=True)

    # Games
    with open(os.path.join(output_dir, "Games.csv"), "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["game_id", "home_team", "away_team", "date", "venue", "competition_name"])
        writer.writerow(["game1", "TeamA", "TeamB", "2025-09-15", "Demo Field", "Friendly"])

    # Players
    with open(os.path.join(output_dir, "Players.csv"), "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["player_id", "displayName", "position", "team_affiliation"])
        for i in range(1, 23):
            team = "home" if i <= 11 else "away"
            writer.writerow([f"p{i}", f"Player {i}", "" if i == 1 else "Field", team])

    # Plays
    with open(os.path.join(output_dir, "Plays.csv"), "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["game_id", "play_id", "period", "game_clock", "team_in_possession", "play_type"])
        writer.writerow(["game1", "play1", 1, "10:00", "home", "long_pass_initiated"])

    # Tracking
    with open(os.path.join(output_dir, "Tracking.csv"), "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            "game_id",
            "play_id",
            "frame_id",
            "timestamp",
            "object_id",
            "team",
            "x",
            "y",
            "speed",
            "acceleration",
            "direction_of_travel",
            "orientation",
        ])
        frame = 0
        for t in [0.0, 0.5, 1.0]:
            for i in range(1, 23):
                team = "home" if i <= 11 else "away"
                writer.writerow([
                    "game1",
                    "play1",
                    frame,
                    t,
                    f"p{i}" if i < 23 else "ball",
                    team,
                    random.uniform(0, 100),
                    random.uniform(0, 60),
                    random.uniform(0, 5),
                    random.uniform(0, 1),
                    random.uniform(0, 6.28),
                    random.uniform(0, 6.28),
                ])
                frame += 1
        # Append ball tracking
        writer.writerow([
            "game1",
            "play1",
            frame,
            0.0,
            "ball",
            "",  # ball has no team
            random.uniform(0, 100),
            random.uniform(0, 60),
            random.uniform(0, 10),
            random.uniform(0, 2),
            random.uniform(0, 6.28),
            random.uniform(0, 6.28),
        ])

    print(f"Dummy data written to {output_dir}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Preprocess raw data")
    parser.add_argument("--input-dir", type=str, required=False, default="data/raw", help="Directory with raw data")
    parser.add_argument("--output-dir", type=str, required=True, help="Directory for processed CSV tables")
    args = parser.parse_args()
    generate_dummy_data(args.input_dir, args.output_dir)


if __name__ == "__main__":
    main()