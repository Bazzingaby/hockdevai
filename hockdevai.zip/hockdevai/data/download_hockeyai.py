"""
Download the HockeyAI dataset from Hugging Face.

The HockeyAI dataset is an open‑source multi‑class object detection
dataset with 2 100 frames and YOLO annotations for seven classes
including players and the puck【921815307126454†L238-L255】.  This script
downloads the dataset archive and extracts it into a local directory.

Usage:

```
python data/download_hockeyai.py --output-dir data/raw
```
"""
import argparse
import os
import zipfile

from huggingface_hub import hf_hub_download


REPO_ID = "acmmmsys/2025-HockeyAI"
FILENAME = "HockeyAI.zip"


def download_dataset(output_dir: str) -> None:
    """Download and extract the HockeyAI dataset."""
    os.makedirs(output_dir, exist_ok=True)
    archive_path = hf_hub_download(repo_id=REPO_ID, filename=FILENAME, cache_dir=output_dir)
    with zipfile.ZipFile(archive_path, "r") as zf:
        zf.extractall(output_dir)
    print(f"Dataset extracted to {output_dir}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Download HockeyAI dataset")
    parser.add_argument("--output-dir", type=str, default="data/raw", help="Destination directory")
    args = parser.parse_args()
    download_dataset(args.output_dir)


if __name__ == "__main__":
    main()