import React, { useState } from 'react';
import PlayVisualizer from './PlayVisualizer.jsx';

function Dashboard() {
  const [responses, setResponses] = useState(null);

  async function handleTestPrediction() {
    // Construct a dummy game state payload
    const payload = {
      game_id: 'game1',
      play_id: 'play1',
      timestamp: 0.0,
      ball_x: 50.0,
      ball_y: 25.0,
      ball_speed: 5.0,
      ball_direction: 0.0,
      players: [
        { player_id: 'p1', team: 'home', x: 10, y: 20, speed: 1, direction: 0 },
        { player_id: 'p2', team: 'home', x: 20, y: 30, speed: 1, direction: 0 },
        { player_id: 'p3', team: 'away', x: 30, y: 40, speed: 1, direction: 0 },
        { player_id: 'p4', team: 'away', x: 40, y: 50, speed: 1, direction: 0 },
      ],
    };
    const res = await fetch('http://localhost:8000/predict', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    setResponses(data);
  }

  return (
    <div>
      <button onClick={handleTestPrediction}>Run Test Prediction</button>
      {responses && (
        <pre>{JSON.stringify(responses, null, 2)}</pre>
      )}
      <PlayVisualizer />
    </div>
  );
}

export default Dashboard;