import React from 'react';
import Dashboard from './components/Dashboard.jsx';

function App() {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>HockDevAI Dashboard</h1>
      <Dashboard />
    </div>
  );
}

export default App;