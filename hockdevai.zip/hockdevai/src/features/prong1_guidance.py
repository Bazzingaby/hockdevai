"""
Prong 1 – Guidance System

This module estimates the landing position and hang time of a long pass or
aerial ball.  For demonstration purposes we use a simple linear model: the
ball's current position plus its velocity vector multiplied by a constant
hang time.  In a production system you would solve differential equations
accounting for gravitational acceleration and aerodynamic drag.
"""
from typing import Dict

from ..app.main import GameState


def compute_guidance_features(game_state: GameState) -> Dict[str, float]:
    """Compute physics‑based features for the ball trajectory.

    Returns a dictionary with keys `predicted_ball_landing_x`,
    `predicted_ball_landing_y` and `predicted_hang_time`.  The current
    implementation is a heuristic that assumes the ball travels in a
    straight line at its current speed for one second.
    """
    # Default hang time (seconds)
    hang_time = 1.0
    vx = 0.0
    vy = 0.0

    if game_state.ball_speed is not None and game_state.ball_direction is not None:
        # Convert polar speed/direction into Cartesian components
        import math
        vx = game_state.ball_speed * math.cos(game_state.ball_direction)
        vy = game_state.ball_speed * math.sin(game_state.ball_direction)
        hang_time = 1.5  # pretend we estimate hang time from speed

    landing_x = game_state.ball_x + vx * hang_time
    landing_y = game_state.ball_y + vy * hang_time

    return {
        "predicted_ball_landing_x": landing_x,
        "predicted_ball_landing_y": landing_y,
        "predicted_hang_time": hang_time,
    }