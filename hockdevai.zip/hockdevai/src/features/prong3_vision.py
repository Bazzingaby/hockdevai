"""
Prong 3 – Vision System

This module computes high‑level spatial dominance metrics.  A full
implementation would grid the entire pitch and calculate the probability
that each team controls each cell based on time‑to‑intercept calculations【737172211721491†L90-L98】.
For demonstration we use a simplified approach: we count the number of
players from each team within a certain radius of the predicted landing
spot and derive a control score.
"""
from typing import Dict

import pandas as pd

from ..app.main import GameState, PlayerState
from .prong2_intelligence import _euclidean_distance


def compute_vision_features(
    game_state: GameState, guidance: Dict[str, float], radius: float = 5.0
) -> pd.DataFrame:
    """Compute pitch‑control features.

    Parameters
    ----------
    game_state: GameState
        The current game state.
    guidance: dict
        Output from the Guidance System.
    radius: float
        Radius around the predicted landing spot to count players.

    Returns
    -------
    pandas.DataFrame
        A DataFrame indexed by player_id with the same control features for
        all players (contextual information).  Real implementations may
        include player‑specific values.
    """

    landing_x = guidance["predicted_ball_landing_x"]
    landing_y = guidance["predicted_ball_landing_y"]

    home_count = 0
    away_count = 0
    for p in game_state.players:
        if _euclidean_distance(p.x, p.y, landing_x, landing_y) <= radius:
            if p.team.lower() == "home":
                home_count += 1
            elif p.team.lower() == "away":
                away_count += 1
    total = home_count + away_count if home_count + away_count > 0 else 1
    control_at_landing = home_count / total
    avg_control_zone = control_at_landing  # same for simplicity
    control_gradient = 0.0  # placeholder

    # Build DataFrame: same values for all players
    df = pd.DataFrame(
        {
            "control_at_landing_spot": [control_at_landing] * len(game_state.players),
            "avg_control_in_reception_zone": [avg_control_zone] * len(game_state.players),
            "control_gradient_along_pass_lane": [control_gradient] * len(game_state.players),
        },
        index=[p.player_id for p in game_state.players],
    )

    return df