"""
Prong 2 – Intelligence Engine

This module computes contextual features for each player at the moment of
pass initiation.  Features quantify the player's relationship to the ball
landing spot and to opponents.  Only basic features are implemented here;
you should extend this with angles, speed differences and team‑level
metrics as described in the main report.
"""
from typing import Dict, List

import pandas as pd

from ..app.main import GameState, PlayerState


def _euclidean_distance(x1: float, y1: float, x2: float, y2: float) -> float:
    return ((x1 - x2) ** 2 + (y1 - y2) ** 2) ** 0.5


def compute_intelligence_features(
    game_state: GameState, guidance: Dict[str, float]
) -> pd.DataFrame:
    """Compute player‑level contextual features.

    Parameters
    ----------
    game_state: GameState
        The current game state.
    guidance: dict
        Output from the Guidance System.

    Returns
    -------
    pandas.DataFrame
        One row per player with engineered features.  Column order is not
        guaranteed; downstream code should refer to column names.
    """

    players: List[PlayerState] = game_state.players
    rows = []

    landing_x = guidance["predicted_ball_landing_x"]
    landing_y = guidance["predicted_ball_landing_y"]

    # Precompute distances between all players for nearest defender
    positions = [(p.x, p.y, p.team) for p in players]

    for i, p in enumerate(players):
        dist_to_landing = _euclidean_distance(p.x, p.y, landing_x, landing_y)

        # Approximate time to intercept as distance divided by speed
        speed = p.speed if p.speed is not None and p.speed > 0 else 1.0
        time_to_intercept = dist_to_landing / speed

        # Find nearest defender (player from opposing team)
        nearest_def_dist = float("inf")
        for xj, yj, team_j in positions:
            if team_j != p.team:
                d = _euclidean_distance(p.x, p.y, xj, yj)
                if d < nearest_def_dist:
                    nearest_def_dist = d

        rows.append(
            {
                "player_id": p.player_id,
                "distance_to_landing_spot": dist_to_landing,
                "time_to_intercept": time_to_intercept,
                "distance_to_nearest_defender": nearest_def_dist,
                # Placeholder values; real implementation would compute these
                "pressure_cone_area": 0.0,
            }
        )

    df = pd.DataFrame(rows)
    df.set_index("player_id", inplace=True)
    return df