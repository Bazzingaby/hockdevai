"""
SQLAlchemy models for the HockDevAI database.

This module defines ORM classes representing the four core tables: Games,
Players, Plays and Tracking.  The metadata can be used with Alembic to
generate migrations and create the PostGIS database schema.
"""
from datetime import date, datetime

from sqlalchemy import (
    Column,
    Date,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    MetaData,
    String,
    Table,
    create_engine,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import declarative_base, relationship


metadata = MetaData()
Base = declarative_base(metadata=metadata)


class Game(Base):
    __tablename__ = "games"
    game_id = Column(String, primary_key=True)
    home_team = Column(String, nullable=False)
    away_team = Column(String, nullable=False)
    date = Column(Date, nullable=False)
    venue = Column(String, nullable=True)
    competition_name = Column(String, nullable=True)
    plays = relationship("Play", back_populates="game")


class Player(Base):
    __tablename__ = "players"
    player_id = Column(String, primary_key=True)
    displayName = Column(String, nullable=False)
    height = Column(Float, nullable=True)
    weight = Column(Float, nullable=True)
    birthDate = Column(Date, nullable=True)
    position = Column(String, nullable=True)
    team_affiliation = Column(String, nullable=False)


class Play(Base):
    __tablename__ = "plays"
    play_id = Column(String, primary_key=True)
    game_id = Column(String, ForeignKey("games.game_id"), nullable=False)
    period = Column(Integer, nullable=True)
    game_clock = Column(String, nullable=True)
    team_in_possession = Column(String, nullable=True)
    play_type = Column(String, nullable=False)
    play_outcome = Column(String, nullable=True)
    game = relationship("Game", back_populates="plays")


class Tracking(Base):
    __tablename__ = "tracking"
    id = Column(Integer, primary_key=True, autoincrement=True)
    game_id = Column(String, ForeignKey("games.game_id"), nullable=False)
    play_id = Column(String, ForeignKey("plays.play_id"), nullable=False)
    frame_id = Column(Integer, nullable=False)
    timestamp = Column(Float, nullable=False)
    object_id = Column(String, nullable=False)
    team = Column(String, nullable=True)
    x = Column(Float, nullable=False)
    y = Column(Float, nullable=False)
    speed = Column(Float, nullable=True)
    acceleration = Column(Float, nullable=True)
    direction_of_travel = Column(Float, nullable=True)
    orientation = Column(Float, nullable=True)


def init_db(url: str = "sqlite:///hockdev.db") -> None:
    """Create all tables in the database specified by URL."""
    engine = create_engine(url)
    Base.metadata.create_all(engine)