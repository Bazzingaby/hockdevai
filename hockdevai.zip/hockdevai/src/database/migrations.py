"""
Alembic migration script placeholder.

In a production system you would use Alembic to manage database schema
migrations.  For simplicity this script just calls `init_db()` from
`models.py` to create tables on a SQLite database or the database
specified by the `DATABASE_URL` environment variable.
"""
import os

from sqlalchemy.engine import make_url

from .models import init_db


def run_migrations() -> None:
    url = os.getenv("DATABASE_URL", "sqlite:///hockdev.db")
    init_db(url)


if __name__ == "__main__":
    run_migrations()