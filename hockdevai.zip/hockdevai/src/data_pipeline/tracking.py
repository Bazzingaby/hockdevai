"""
Simple multi‑object tracker for demonstration.

This module implements a naive nearest‑neighbour tracker that assigns
consistent IDs to detections across frames.  In a production system you
should replace this with a robust tracker (e.g. DeepSORT, ByteTrack).
"""
from typing import Dict, List, Tuple

import numpy as np


class NaiveTracker:
    """A naive tracker that matches detections based on proximity."""

    def __init__(self, max_distance: float = 50.0):
        self.max_distance = max_distance
        self.next_id = 0
        self.tracks: Dict[int, Tuple[float, float]] = {}

    def update(self, detections: List[Tuple[int, float, float, float, float]]) -> List[Tuple[int, float, float, float, float, int]]:
        """Assign IDs to the current detections.

        Parameters
        ----------
        detections: List of tuples `(class_id, x1, y1, x2, y2)`

        Returns
        -------
        List of tuples `(class_id, x1, y1, x2, y2, track_id)`.
        """
        # Compute centroids of detections
        centroids = [((x1 + x2) / 2, (y1 + y2) / 2) for (_, x1, y1, x2, y2) in detections]
        assigned: List[int] = []
        results = []
        for idx, (cls_id, x1, y1, x2, y2) in enumerate(detections):
            cx, cy = centroids[idx]
            # Find existing track within distance threshold
            best_id = None
            best_dist = self.max_distance
            for track_id, (tx, ty) in self.tracks.items():
                dist = ((cx - tx) ** 2 + (cy - ty) ** 2) ** 0.5
                if dist < best_dist:
                    best_id = track_id
                    best_dist = dist
            if best_id is None:
                best_id = self.next_id
                self.next_id += 1
            # Update track
            self.tracks[best_id] = (cx, cy)
            assigned.append(best_id)
            results.append((cls_id, x1, y1, x2, y2, best_id))
        return results