"""
Homography utilities.

This module contains helper functions to compute a homography matrix
between the 2D image plane and a top‑down coordinate system.  Use this to
convert pixel coordinates of players and the ball into real‑world (x, y)
positions on the pitch.
"""
from typing import List, Tuple

import cv2
import numpy as np


def compute_homography(
    src_points: List[Tuple[float, float]], dst_points: List[Tuple[float, float]]
) -> np.ndarray:
    """Compute a homography matrix given point correspondences.

    Parameters
    ----------
    src_points: list of (x, y)
        Coordinates in the image plane.
    dst_points: list of (x, y)
        Corresponding coordinates in the top‑down plane.

    Returns
    -------
    3×3 homography matrix that maps src_points to dst_points.
    """
    if len(src_points) < 4 or len(dst_points) < 4:
        raise ValueError("At least four point pairs are required to compute a homography")
    src = np.array(src_points, dtype=np.float32)
    dst = np.array(dst_points, dtype=np.float32)
    H, _ = cv2.findHomography(src, dst, method=cv2.RANSAC)
    return H


def apply_homography(point: Tuple[float, float], H: np.ndarray) -> Tuple[float, float]:
    """Apply a homography matrix to a single 2D point."""
    x, y = point
    vec = np.array([x, y, 1.0], dtype=np.float32)
    mapped = H @ vec
    if mapped[2] == 0:
        return (float(mapped[0]), float(mapped[1]))
    return (float(mapped[0] / mapped[2]), float(mapped[1] / mapped[2]))