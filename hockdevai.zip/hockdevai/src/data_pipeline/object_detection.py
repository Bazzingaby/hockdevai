"""
Object detection module.

This module provides a wrapper around an off‑the‑shelf object detection model
such as YOLOv8.  It includes methods to load a model, run inference on
frames and filter detections by class.  Use this as a starting point to
integrate your own detector.
"""
from typing import List, Tuple

import cv2
import numpy as np

try:
    import ultralytics
except ImportError:  # pragma: no cover
    ultralytics = None


class Detector:
    """Object detector wrapper."""

    def __init__(self, model_path: str | None = None):
        if ultralytics is None:
            raise ImportError(
                "The ultralytics package is required for object detection. "
                "Install it via pip install ultralytics"
            )
        # Load a pre‑trained YOLOv8 model
        self.model = ultralytics.YOLO(model_path or "yolov8n.pt")

    def detect(self, frame: np.ndarray) -> List[Tuple[int, float, float, float, float]]:
        """Run detection on a single frame.

        Parameters
        ----------
        frame: np.ndarray
            BGR image array as loaded by OpenCV.

        Returns
        -------
        List of tuples `(class_id, x1, y1, x2, y2)` for each detection.
        """
        results = self.model.predict(frame, imgsz=640, conf=0.25, iou=0.45)[0]
        detections = []
        for box, cls in zip(results.boxes.xyxy, results.boxes.cls):
            x1, y1, x2, y2 = box.tolist()
            detections.append((int(cls), x1, y1, x2, y2))
        return detections