"""
FastAPI application for HockDevAI.

This module defines the REST API for prediction and scenario planning.  It
depends on the feature engineering modules and a trained LightGBM model.
All endpoints accept JSON payloads validated with Pydantic models.  See
`/docs` (Swagger) for an interactive UI.
"""
from typing import List, Optional

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

import numpy as np
import pandas as pd

try:
    from lightgbm import LGBMRegressor
except ImportError:  # pragma: no cover
    LGBMRegressor = None

from ..features.prong1_guidance import compute_guidance_features
from ..features.prong2_intelligence import compute_intelligence_features
from ..features.prong3_vision import compute_vision_features


app = FastAPI(title="HockDevAI API", version="0.1.0")


class PlayerState(BaseModel):
    player_id: str
    team: str
    x: float
    y: float
    speed: Optional[float] = None
    direction: Optional[float] = None
    acceleration: Optional[float] = None


class GameState(BaseModel):
    """Representation of the current game state at pass initiation."""

    game_id: str
    play_id: str
    timestamp: float = Field(..., description="Absolute or relative time in seconds")
    ball_x: float
    ball_y: float
    ball_speed: Optional[float] = None
    ball_direction: Optional[float] = None
    players: List[PlayerState]


class PredictionResponse(BaseModel):
    """Predicted future positions and key metrics for each player."""

    player_id: str
    future_x: float
    future_y: float
    prp: Optional[float] = None  # Pass Reception Probability
    dpg: Optional[str] = None    # Defensive Positioning Grade
    scs: Optional[float] = None  # Space Creation Score
    ios: Optional[float] = None  # Interception Opportunity Score
    ofv: Optional[float] = None  # Offensive Formation Value


def load_model() -> Optional[LGBMRegressor]:
    """Load a trained LightGBM model from disk.

    Returns None if the model file does not exist.
    """
    import os
    import joblib

    model_path = os.path.join(os.path.dirname(__file__), "..", "model", "model.pkl")
    try:
        return joblib.load(model_path)
    except FileNotFoundError:
        return None


model = load_model()


@app.post("/predict", response_model=List[PredictionResponse])
async def predict_positions(game_state: GameState):
    """Predict future positions for all players given the current game state.

    This endpoint wraps the three prongs (guidance, intelligence and vision)
    and feeds the combined features into a trained LightGBM model.  If no
    trained model is available, it returns a dummy prediction where the
    future position equals the current position.
    """

    # Compute guidance features common to all players
    guidance = compute_guidance_features(game_state)

    # Compute intelligence features per player
    intelligence = compute_intelligence_features(game_state, guidance)

    # Compute vision features common to all players
    vision = compute_vision_features(game_state, guidance)

    # Combine features into DataFrame
    feature_df = pd.concat([intelligence, vision], axis=1)

    responses: List[PredictionResponse] = []

    if model is None:
        # Return current positions if model is missing
        for p in game_state.players:
            responses.append(
                PredictionResponse(
                    player_id=p.player_id,
                    future_x=p.x,
                    future_y=p.y,
                )
            )
        return responses

    # Predict positions
    X = feature_df.values  # type: ignore[arg-type]
    y_pred = model.predict(X)

    for i, p in enumerate(game_state.players):
        responses.append(
            PredictionResponse(
                player_id=p.player_id,
                future_x=float(y_pred[i][0]),
                future_y=float(y_pred[i][1]),
                # Additional KPIs can be computed here
            )
        )
    return responses


@app.post("/what_if", response_model=List[PredictionResponse])
async def what_if(game_state: GameState):
    """Re‑run the prediction pipeline after the user modifies one or more
    player positions.  This endpoint has the same semantics as `/predict`;
    the frontend should call it when the coach drags a player in the UI."""

    return await predict_positions(game_state)


@app.post("/load_game")
async def load_game(games: List[dict]):
    """Placeholder endpoint to demonstrate data loading.

    In a real deployment this would parse uploaded CSV files or a JSON
    payload and store the records in the database.  For now it simply
    returns the received payload.
    """

    return {"status": "received", "records": len(games)}