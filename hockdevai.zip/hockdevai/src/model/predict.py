"""
Predict future player positions using a trained model.

This script loads a saved LightGBM model and runs inference on a
constructed GameState object.  It can be used for quick testing without
spinning up the full FastAPI server.
"""
import argparse
import os
from typing import List

import joblib
import pandas as pd

from ..app.main import GameState, PlayerState
from ..features.prong1_guidance import compute_guidance_features
from ..features.prong2_intelligence import compute_intelligence_features
from ..features.prong3_vision import compute_vision_features


def build_dummy_state() -> GameState:
    players: List[PlayerState] = []
    # Create a few dummy players
    for i in range(1, 5):
        team = "home" if i <= 2 else "away"
        players.append(
            PlayerState(
                player_id=f"p{i}",
                team=team,
                x=float(i * 10),
                y=float(i * 5),
                speed=1.0,
                direction=0.0,
                acceleration=0.0,
            )
        )
    return GameState(
        game_id="game1",
        play_id="play1",
        timestamp=0.0,
        ball_x=50.0,
        ball_y=25.0,
        ball_speed=5.0,
        ball_direction=0.0,
        players=players,
    )


def predict(model_path: str) -> None:
    model = joblib.load(model_path)
    state = build_dummy_state()
    guidance = compute_guidance_features(state)
    intel = compute_intelligence_features(state, guidance)
    vision = compute_vision_features(state, guidance)
    features = pd.concat([intel, vision], axis=1)
    y_pred = model.predict(features.values)
    print("Predictions:")
    for pid, coords in zip(features.index, y_pred):
        print(pid, coords)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run predictions with trained model")
    parser.add_argument("--model", type=str, default="src/model/model.pkl", help="Path to saved model")
    args = parser.parse_args()
    predict(args.model)


if __name__ == "__main__":
    main()