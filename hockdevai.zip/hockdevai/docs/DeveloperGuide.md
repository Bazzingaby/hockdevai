# Developer Guide

This guide is for contributors who want to extend or customize the HockDevAI
codebase.  It outlines the repository structure, coding standards, testing
approach and deployment procedures.

## 1. Repository Structure

```
hockdevai/
├── data/                 # Scripts for downloading and preprocessing datasets
│   ├── download_hockeyai.py
│   └── preprocessing.py
├── docs/                 # Project documentation
│   ├── ArchitectureOverview.md
│   ├── DataAcquisition.md
│   ├── DeveloperGuide.md
│   └── UserGuide.md
├── src/
│   ├── app/              # FastAPI application
│   │   └── main.py
│   ├── data_pipeline/    # Object detection, tracking and homography
│   │   ├── object_detection.py
│   │   ├── tracking.py
│   │   └── homography.py
│   ├── database/         # SQLAlchemy models and migration scripts
│   │   ├── models.py
│   │   └── migrations.py
│   ├── features/         # Feature engineering modules
│   │   ├── prong1_guidance.py
│   │   ├── prong2_intelligence.py
│   │   └── prong3_vision.py
│   ├── model/            # Machine learning training and inference
│   │   ├── train.py
│   │   └── predict.py
│   └── frontend/         # Placeholder for React UI
│       ├── package.json
│       └── src/
│           ├── components/
│           │   ├── Dashboard.jsx
│           │   └── PlayVisualizer.jsx
│           └── App.jsx
├── docker-compose.yaml   # Docker services for API and database
├── requirements.txt
├── LICENSE
└── README.md
```

## 2. Coding Standards

- **Python version** – use Python 3.10 or higher.  Type hints are
  encouraged for all new functions.
- **Formatting** – run `flake8` for linting and `black` for code formatting.
  Optionally use `pre-commit` to automatically format code on commit.
- **Imports** – organize imports using `isort`; group standard library,
  third‑party and local imports separately.

## 3. Virtual Environment Setup

Create a virtual environment and install dependencies:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

For front‑end development, install Node.js and run `npm install` inside
`src/frontend`.

## 4. Data Pipeline Development

### 4.1 Object Detection

`src/data_pipeline/object_detection.py` includes a `Detector` class that
wraps a YOLOv8 model loaded via `torch.hub` or `ultralytics`.  Modify
`Detector.detect()` to read frames from your data source and return a list
of detections with class IDs and bounding boxes.  Training scripts can be
added in a separate `scripts/` folder if you wish to fine‑tune the model.

### 4.2 Multi‑Object Tracking

`src/data_pipeline/tracking.py` implements a simple tracker based on
Kalman filtering and IoU‑based assignment.  You can replace this with
DeepSORT, ByteTrack or your preferred algorithm.  Pay special attention
to jersey numbers and team colours for player identification【787101157054691†L82-L90】.

### 4.3 Homography

`src/data_pipeline/homography.py` contains functions to calculate a
homography matrix given at least four corresponding points between the
image and the pitch.  Use OpenCV’s `findHomography` and `warpPerspective`
functions.

## 5. Feature Engineering

The three prongs live in `src/features/`:

1. **prong1_guidance.py** – implements ballistic trajectories with drag.
2. **prong2_intelligence.py** – computes distances, times to intercept and
   opponent pressures.
3. **prong3_vision.py** – calculates pitch‑control values by gridding the
   pitch and computing probabilities【737172211721491†L90-L98】.

Ensure that each module returns a pandas DataFrame with one row per player
and columns for all engineered features.

## 6. Model Training

`src/model/train.py` demonstrates how to merge features from the three
prongs and train a LightGBM regressor to predict future player positions.
Hyperparameters are stored in a dictionary; feel free to experiment with
XGBoost or CatBoost.  Save trained models under `models/`.

`src/model/predict.py` loads a trained model and wraps it for inference.
Both scripts rely on the `lightgbm` package and scikit‑learn interfaces.

## 7. Backend and API

The FastAPI application (`src/app/main.py`) exposes endpoints for
prediction and scenario analysis.  Use Pydantic models to validate
incoming JSON data.  If you add new endpoints, document them in the
OpenAPI docstrings.

To connect to the database, configure the `DATABASE_URL` environment
variable.  Use SQLAlchemy ORM classes defined in `src/database/models.py`
for CRUD operations.

## 8. Frontend Development

The current frontend is a placeholder.  It uses Vite and React.  Key
components:

- `Dashboard.jsx` – renders the navigation and summary panels.
- `PlayVisualizer.jsx` – draws the pitch and animates player and ball
  trajectories using SVG or Canvas.

Feel free to replace the design entirely with your own UI framework.

## 9. Testing

Unit tests should reside in a `tests/` directory.  Use `pytest` for
testing Python code and `jest` for React components.  Continuous
integration can be configured via GitHub Actions; see `.github/workflows` in
your own fork for examples.

## 10. Deployment

Use the provided `docker-compose.yaml` to run the database and API
services.  For production, build a multi‑stage Dockerfile that compiles
the frontend into static files served by a lightweight web server such as
NGINX.

When deploying to AWS or GCP, consider using managed services for
PostgreSQL and container orchestration (e.g. ECS, EKS or Cloud Run).

## 11. Contributing

Contributions are welcome!  Please fork the repository, create a feature
branch and open a pull request.  Ensure that your code passes tests and
adheres to the style guide.  If your change affects the public API or
documentation, update the relevant Markdown files.