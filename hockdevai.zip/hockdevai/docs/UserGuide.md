# User Guide

This guide explains how to use the HockDevAI web application to analyse
long‑pass plays and explore tactical options.  The target audience is
coaches, analysts and players who want intuitive insights without digging
into code or raw data.

## 1. Launching the Application

After installing dependencies and running `python src/app/main.py`, visit
`http://localhost:8000/docs` in your web browser.  This page shows the
auto‑generated Swagger UI from FastAPI.  You can test API calls directly
from the browser.

To start the frontend:

```bash
cd src/frontend
npm install
npm run dev
```

Then open `http://localhost:5173` (or the port displayed in your terminal) to
view the dashboard.  The frontend will proxy API requests to the backend.

## 2. Uploading Data

The dashboard requires tracking and event data to populate the visualizer.
Currently the backend includes a `POST /load_game` endpoint where you can
upload CSV files for `Games`, `Players`, `Plays` and `Tracking`.  In future
versions we plan to integrate directly with your PostGIS database.

Once the data is loaded, select a game from the dropdown and then choose a
play (e.g. a long‑pass event) to analyse.

## 3. Play Visualizer

The play visualizer shows the pitch in a top‑down view with icons for each
player and the ball.  The timeline slider allows you to scrub through the
play.  You can toggle the following overlays:

- **Actual paths** – the real trajectories of players during the play.
- **Predicted paths** – “ghost” trajectories showing where the model
  predicted players would go.  Comparing predicted vs. actual movement
  helps identify tactical errors or exceptional plays.
- **Pitch‑control heatmap** – a colour gradient indicating which team
  controls each region of the pitch at each moment【737172211721491†L90-L98】.
- **Ball trajectory** – a curve showing the predicted path of an aerial pass.

Clicking on a player displays their contextual features (distance to
landing spot, time to intercept, nearest defender, etc.) computed by the
Intelligence Engine.

## 4. “What If” Scenario Planner

To explore alternative strategies, use the scenario planner:

1. Pause the play at the moment of pass initiation.
2. Drag any player icon to a new starting position.
3. The frontend sends the modified positions to the `/what_if` endpoint.
4. The backend reruns the model and returns new predictions and key
   performance indicators.

This tool allows you to test questions like “What if the midfielder started
two metres wider?” or “Would a deeper defensive line intercept the pass?”
without re‑watching hours of footage.

## 5. Interpreting KPIs

The interface displays several proprietary key performance indicators (KPIs),
derived from the Trident model:

| KPI | Meaning |
|----|---------|
| **Pass Reception Probability (PRP)** | Probability that the intended receiver will reach the predicted landing spot before any defender, based on relative times to intercept. |
| **Defensive Positioning Grade (DPG)** | A letter grade evaluating how closely a defender’s actual path matched the model’s optimal path. |
| **Space Creation Score (SCS)** | Quantifies how much an attacker’s movement drew defenders away from the passing lane, measured by the change in pitch control. |
| **Interception Opportunity Score (IOS)** | Highlights moments when a defender could have intercepted the ball by deviating from their actual path. |
| **Offensive Formation Value (OFV)** | Scores the attacking team’s overall shape by aggregating the PRP of all potential receivers. |

High PRP values indicate a safe pass; low PRP suggests a risky attempt.  A
low DPG for a defender signals poor positioning relative to the model’s
recommendation.  Use these KPIs to communicate insights succinctly to
players and staff.

## 6. Exporting Results

The frontend provides buttons to export visualizations and tables as
PNG images or CSV files for inclusion in reports or presentations.  Future
iterations will include options to automatically generate season‑long
summaries and trend charts.

## 7. Troubleshooting

If the dashboard doesn’t load or the API returns an error:

1. Check that the backend server is running on the expected port (`8000`).
2. Verify that your database is running and the migration scripts have
   created the required tables.
3. Inspect the backend logs for stack traces; the service prints errors
   to the console.

For additional support or to request new features, please open an issue on
GitHub.