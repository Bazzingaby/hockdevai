# Architecture Overview

This document outlines the end‑to‑end architecture of the HockDevAI platform.
The design follows the **Trident Initiative** blueprint, integrating
data ingestion, machine‑learning analytics and user‑facing services.

## 1. High‑Level System Diagram

```
           ┌──────────────────────────────────────────────────────┐
           │              Frontend (React)                       │
           │                                                      │
           │  Coach's Dashboard        │  What‑If Planner         │
           └───────────────▲────────────┬─────────────▲──────────┘
                           │            │             │
                           │ REST/JSON  │ WebSocket   │
                           ▼            ▼             ▼
                  ┌────────────────────────────────────────┐
                  │            Backend (FastAPI)           │
                  │                                        │
                  │  /predict endpoint  │  /what_if endpoint │
                  └───────────────▲─────────────────────────┘
                                  │
                 ┌────────────────┴───────────────────┐
                 │                                    │
                 ▼                                    ▼
    ┌────────────────────────┐        ┌──────────────────────────┐
    │     Feature Engine     │        │   Pitch Control Module   │
    └─────────────▲──────────┘        └─────────────▲────────────┘
                  │                               │
                  ▼                               ▼
      ┌──────────────────────────┐    ┌──────────────────────────┐
      │  Physics (Guidance)      │    │  Intelligence (Context)  │
      └─────────────▲────────────┘    └─────────────▲────────────┘
                    │                             │
                    ▼                             ▼
                Tracking Data & Events            External Data
```

## 2. Data Layer

All input data—video frames, annotations, event logs and tracking data—are
normalized into a relational schema.  We use **PostgreSQL** with the
**PostGIS** extension to store spatial coordinates efficiently.  Spatial
queries such as nearest‑neighbour searches are executed at the database
layer using indexes, drastically reducing latency compared with naive in‑memory
loops【69334003373070†L65-L136】.

The four primary tables are **Games**, **Players**, **Plays** and **Tracking** as
described in the [Data Acquisition Guide](DataAcquisition.md).  Alembic
migrations (in `src/database/migrations.py`) create these tables and set
constraints.

## 3. Data Pipeline

1. **Object Detection** – `src/data_pipeline/object_detection.py` provides a
   template for loading a YOLOv8 model and running inference on each frame.
   Detected bounding boxes and class labels (players, puck, etc.) are stored
   in memory or written to disk.  Start with the pre‑trained HockeyAI model
   or fine‑tune your own.
2. **Multi‑Object Tracking** – `src/data_pipeline/tracking.py` uses a
   simple Kalman filter and DeepSORT‑style association to assign consistent
   IDs across frames.  Domain‑specific cues like jersey numbers and team
   colours can greatly improve association accuracy【787101157054691†L82-L90】.
3. **Homography** – `src/data_pipeline/homography.py` computes a
   transformation matrix between pixel coordinates and real‑world (x, y)
   coordinates using known field markings.
4. **Event Parsing** – Additional scripts parse event data (e.g. long
   passes, penalty corners) to label the exact frame at which a play
   begins.
5. **Ingestion** – The processed tracking and event data are loaded into
   the PostGIS database via SQLAlchemy models in `src/database/models.py`.

## 4. Feature Engineering (Three Prongs)

### 4.1 Guidance System

Predicts the future landing position and hang time of an aerial pass.  The
physics model solves differential equations incorporating gravity and a
drag force proportional to the square of velocity.  Since the drag
coefficient of a field‑hockey ball is not well documented, treat it as a
parameter estimated from data.  The output features are `predicted_ball_landing_x`,
`predicted_ball_landing_y` and `predicted_hang_time`.

### 4.2 Intelligence Engine

Generates features describing each player’s relationship to the predicted
landing spot and to opponents.  Features include:

- **distance_to_landing_spot** – Euclidean distance to the predicted landing
  position.
- **time_to_intercept** – estimated time for the player to reach the landing
  spot based on current speed and a maximum acceleration parameter.
- **distance_to_nearest_defender** and **pressure_cone_area** – quantify
  defensive pressure around potential receivers.

These features adapt methods from the NFL Big Data Bowl winners: the
2024 champions computed missed tackle probabilities by comparing distances
and times to intercept【979651112396528†L55-L78】.

### 4.3 Vision System

Implements a pitch‑control model similar to the work of Spearman and
extensions by NFL analytics teams.  The pitch is gridded into fine cells
and, for each cell, the probability that each team will reach the cell
first is calculated using time‑to‑intercept functions【737172211721491†L90-L98】.
The resulting control map is distilled into a few high‑level features such
as control at the landing spot and control gradients along the passing lane.

## 5. Machine‑Learning Model

The outputs of the three prongs are concatenated into a feature vector for
each player at the moment of pass initiation.  A **LightGBM** model is
trained to predict the player’s coordinates after `N` seconds (where `N` is
the predicted hang time).  LightGBM efficiently handles heterogeneous
features without requiring explicit normalization and is fast on large
datasets.

## 6. Application Layer

### 6.1 Backend (FastAPI)

The backend exposes endpoints to:

1. **/predict** – accepts a game state (players’ positions, ball position and
   contextual metadata), runs the three prongs and returns predicted
   trajectories.
2. **/what_if** – accepts a hypothetical player position change and runs the
   full pipeline to return new predictions, enabling interactive scenario
   planning.

### 6.2 Frontend (React)

A minimal React application (in `src/frontend`) demonstrates how to render
the pitch, animate player trajectories and overlay pitch‑control heat maps.
It also interfaces with the `/what_if` endpoint to update predictions in
real time.  You can expand the front end with your own UI/UX design.

## 7. Deployment

Use Docker and docker‑compose to run the database and API in a consistent
environment.  The provided `docker-compose.yaml` file defines services for
PostgreSQL (with PostGIS) and the FastAPI backend.  For production
deployments, consider using a managed cloud service and enabling HTTPS.
