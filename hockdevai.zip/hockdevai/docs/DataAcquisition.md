# Data Acquisition Guide

This guide explains how to obtain and preprocess the open‑source datasets used
in this project.  HockDevAI is designed to be agnostic to the underlying
data source—any player and ball tracking data with timestamps can be loaded
into the pipeline.  To bootstrap development, we recommend using publicly
available computer‑vision datasets and simulated tracking data.

## 1. HockeyAI Dataset for Object Detection

The [HockeyAI dataset](https://github.com/acmmmsys/2025-HockeyAI) is a
multi‑class ice‑hockey dataset released under an MIT License.  Although
designed for ice hockey, it is well suited to train a detector that can
distinguish players, referees, the puck and key rink features.  The dataset
contains **2 100 high‑resolution frames** with YOLO‑format annotations for
seven classes: centre ice, faceoff dots, goal frame, goaltender, player,
puck and referee【921815307126454†L238-L255】.  Annotations are provided in the
standard YOLO text files, making it easy to fine‑tune any modern detector.

### 1.1 Downloading HockeyAI

Use the script `data/download_hockeyai.py` to download the dataset from the
Hugging Face repository.  The script uses the `huggingface_hub` library to
fetch the zip archive and extract it into the `data/raw/` directory:

```bash
python data/download_hockeyai.py --output-dir data/raw
```

This will create a folder structure like:

```
data/
└── raw/
    └── HockeyAI/
        ├── images/
        └── labels/
```

### 1.2 Converting to Field Hockey

The dataset’s annotations are for ice hockey; converting them to field
hockey requires a few steps:

1. Select the relevant classes (`player` and `puck`) and ignore rink‑specific
   classes such as `faceoff`.
2. Optionally re‑label the images by cropping or masking the rink boards to
   approximate a field boundary.
3. Fine‑tune a YOLOv8 model on the filtered dataset and your own
   field‑hockey footage.  The script `src/data_pipeline/object_detection.py`
   provides a template for training and inference.

## 2. Event‑Based Data

In addition to video frames, you may need event logs (e.g. play‑by‑play
information) to label long passes and other tactical actions.  Sources
include:

- **NCAA field hockey video exchange** – the Spiideo platform records and
  tags thousands of NCAA games per season.  While not directly open, some
  institutions share tagged event data for academic research【355475592135848†L151-L162】.
- **Simulated tracking data** – publicly released soccer tracking datasets
  such as those generated in [Google Research Football](https://arxiv.org/pdf/2206.15419.pdf) or the
  SportsSUSHI dataset provide realistic trajectories and event labels for
  research【410731994837348†L73-L83】.  Use these data to test the pipeline
  while awaiting access to real field‑hockey tracking data.

## 3. Data Schema

Regardless of the source, normalize all data into the four core tables
described in the main report:

| Table | Purpose | Key Columns |
|------|---------|-------------|
| `Games` | Metadata per game | `game_id`, `home_team`, `away_team`, `date` |
| `Players` | Static info per player | `player_id`, `displayName`, `position`, `team_affiliation` |
| `Plays` | Context per play | `play_id`, `game_id`, `period`, `play_type`, `team_in_possession` |
| `Tracking` | High‑frequency positions | `frame_id`, `timestamp`, `x`, `y`, `object_id`, `team` |

Use the script `data/preprocessing.py` to convert raw tracking and event
files into these tables.  The PostGIS database definitions live in
`src/database/models.py`.

## 4. Licensing and Attribution

Always respect the licenses of external datasets.  HockeyAI is licensed
under MIT【921815307126454†L238-L255】; if you distribute the dataset or a
model trained on it, include the appropriate citation and license file.
