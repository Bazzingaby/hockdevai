# HockDevAI – Field Hockey Tactical Analytics Platform

HockDevAI is an open‑source prototype inspired by the **Trident Initiative**, a
blue‑ocean strategy to bring NFL‑style tactical analytics to field hockey.  The
goal of this project is to demonstrate a complete analytics workflow—from
data acquisition through machine‑learning models to an interactive web
application—using only freely available resources.  Coaches, analysts and
researchers can use this repository as a starting point for building their
own tactical insight systems.

## Features

- **Data acquisition** – scripts to download public datasets such as the
  [HockeyAI dataset](https://github.com/acmmmsys/2025-HockeyAI) for
  object detection and tracking.  HockeyAI provides 2 100 high‑resolution
  frames with YOLO‑format annotations for seven classes including players and
  the puck【921815307126454†L238-L255】.  You can adapt these annotations for
  field‑hockey or use your own data.
- **Pipeline** – modular code for object detection, multi‑object tracking and
  perspective transformation (homography).  The pipeline converts raw video
  frames into a top‑down coordinate system and generates player/ball
  trajectories.
- **Feature engineering** – three “prongs” derived from the Trident model:
  a **Guidance System** that predicts ball trajectories with aerodynamic
  drag, an **Intelligence Engine** that computes player‑ and team‑centric
  features, and a **Vision System** that calculates pitch‑control maps.
- **Predictive model** – a sample LightGBM implementation that learns to
  predict future player positions from engineered features.
- **Web application** – a FastAPI backend serving predictions and a placeholder
  React frontend for a coach’s dashboard with a play visualizer and “What If”
  scenario planner.
- **Documentation** – comprehensive guides on data acquisition, system
  architecture, user instructions and developer contribution.

## Prerequisites

1. **Python 3.10+** with virtualenv or conda.
2. **Node.js** and **npm** for building the frontend (optional if you only
   use the API).
3. **Docker** and **docker‑compose** (recommended) for running the database
   and API in a reproducible environment.
4. **PostgreSQL 15+** with the PostGIS extension if you prefer running the
   database outside Docker.

## Quick Start

Follow these steps to set up the environment and run a simple demonstration:

```bash
# 1. Clone this repository (or copy its contents to your local machine)
git clone https://github.com/Bazzingaby/hockdevai.git
cd hockdevai

# 2. Create a Python environment
python3 -m venv .venv
source .venv/bin/activate
pip install -U pip
pip install -r requirements.txt

# 3. Download a sample dataset
python data/download_hockeyai.py --output-dir data/raw

# 4. Preprocess the data
python data/preprocessing.py --input-dir data/raw --output-dir data/processed

# 5. Train the model
python src/model/train.py --data-dir data/processed

# 6. Start the API (FastAPI on Uvicorn)
python src/app/main.py

# 7. Explore the API
open http://localhost:8000/docs

# 8. (Optional) Run the frontend
cd src/frontend
npm install
npm run dev
```

For more detailed instructions, see the **docs/** directory.

## Citation

If you use this prototype or the HockeyAI dataset in your work, please cite
the original authors as described in the [HockeyAI README](https://github.com/acmmmsys/2025-HockeyAI).

## License

This project is licensed under the MIT License.  See [LICENSE](LICENSE) for
details.